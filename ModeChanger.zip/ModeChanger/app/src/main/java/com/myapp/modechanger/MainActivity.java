package com.myapp.modechanger;

import android.media.AudioManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Spinner spnmode;
    Button btnchangemode;
    AudioManager manager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        HandleEvent();
    }

    private void HandleEvent() {
        ButtonListener listener = new ButtonListener();
        btnchangemode.setOnClickListener(listener);

    }

    private void init() {
        spnmode = findViewById(R.id.spnmode);
        btnchangemode = findViewById(R.id.btnchangemode);
        manager = (AudioManager) getSystemService(AUDIO_SERVICE);
    }

    class ButtonListener implements View.OnClickListener
    {

        @Override
        public void onClick(View view) {
            int position = spnmode.getSelectedItemPosition();
            if(position==0) //ringing mode
            {
                manager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            }
            else
            {
                manager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
            }
        }
    }
}
